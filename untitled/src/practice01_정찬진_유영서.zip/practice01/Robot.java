
public class Robot {
    private Machine location;
    private String bin;

    public Robot() {}

    public Machine getLocation() {
        return location;
    }

    public String getBin() {
        return bin;
    }

    public void moveTo(Machine location) {
        this.location = location;
    }

    public void setBin(String bin) {
        this.bin = bin;
    }

    public void moveBasketToRobot() {
    	this.bin = location.clearBasket();
    }

    public void moveBasketToMachine() {
        location.setBasket(bin);
        bin = null;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        return sb.append(location!=null ? " location = " + location.getName() : "")
                .append(bin!=null ? " bin = " + bin : "").toString();
    }
}
