public class Machine {
    private String name;
    private String location;
    private String basket;

    public Machine(String name, String location) {
        this.name = name;
        this.location = location;
    }

    public String clearBasket() {
        String result = basket;
        basket = null;
        return result;
    }

    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public String getBasket() {
        return basket;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setBasket(String basket) {
        this.basket = basket;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        return sb.append("Machine : ").append(name)
                .append(basket != null ? " bin = " + basket : "")
                .append("\n").toString();
    }
}